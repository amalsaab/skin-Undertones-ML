from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpRequest

def home_page(request: HttpRequest) -> HttpResponse:
    return render(request, 'detectundertone/home_page.html')

# Create your views here.
